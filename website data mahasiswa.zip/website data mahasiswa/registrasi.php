<?php
require 'function.php';
    
function registrasi($data){
    global $conn;

    $username = strtolower(stripslashes($data["username"]));
    // pass jadi bisa tanda kutip 
    $password = mysqli_real_escape_string($conn, $data["password"]);
    $password2 = mysqli_real_escape_string($conn, $data["password2"]);

    //cek username sudah dipake/sudah ada apa blm
    $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
    
    if( mysqli_fetch_assoc($result) ){
        echo "
            <script>
                alert('Username sudah terdaftar');
            </script>
             ";
             return false;
    }

    //cek konfirmasi pass
    if( $password !== $password2 ){
        echo "
            <script>
                alert('Konfirmasi Password tidak sesuai');
            </script>
             ";
             return false;
    }

    //enkripsi password
    $password = password_hash($password, PASSWORD_DEFAULT);

    
    //tambahkan userbaru ke DB
    mysqli_query($conn, "INSERT INTO user VALUES('', '$username', '$password')");
    return mysqli_affected_rows($conn);
     
}

if ( isset($_POST["register"]) ) {

    if( registrasi($_POST) > 0 ) {
        echo "
            <script>
                alert('User baru berhasil di tambahkan!');
            </script>
            ";
        header("Location: login.php");
        exit;
    } else {
        echo mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi</title>
    <style>
        label{
            display: block; 
        }
    </style>
</head>
<body>
    
    <h1>Registrasi</h1>
    <form action="" method="post">
        <ul>
            <li>
                <label for="username">Username : </label>
                <input type="text" name="username" id="username">
            </li>
            <li>
                <label for="password">Password : </label>
                <input type="password" name="password" id="password">
            </li>
            <li>
                <label for="password2">Re-Password : </label>
                <input type="password" name="password2" id="password2">
            </li>
            <li>
                <button type="submit" name="register">Regitser</button>
            </li>
        </ul>
    </form>

</body>
</html>